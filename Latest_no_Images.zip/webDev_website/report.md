 Issues And How We Resolved Them
----------------------------------------

1)
Issue: Couldn't position text within nested grid element to center correctly (vertially).
Resolution: I've used flexbox that didn't take account for how elements where structured / nested, and simply centered given text.

2)
